import tkinter as tk
from tkinter import messagebox, ttk
import matplotlib.pyplot as plt

# Variables globales
nomina_mensual = [0] * 12  # Lista para registrar la nómina por mes
docentes_contratados = []   # Lista para almacenar los docentes contratados

def contratar_profesor():
    try:
        # Obtener y validar el mes
        mes_texto = entry_mes.get().strip()
        if not mes_texto.isdigit():
            messagebox.showerror("Error", "Ingrese un mes válido entre 1 y 12")
            return
        mes = int(mes_texto)
        if not (1 <= mes <= 12):
            messagebox.showerror("Error", "El mes debe estar entre 1 y 12")
            return
        
        tipo_docente = tipo_var.get()
        salario_mensual = 0
        puntos_o_horas = 0
        
        if tipo_docente == "Planta":
            # Obtener y validar los valores de docentes de planta
            puntos_texto = entry_puntos.get().strip()
            valor_punto_texto = entry_valor_punto.get().strip()

            if not puntos_texto.replace(".", "").isdigit() or not valor_punto_texto.replace(".", "").isdigit():
                messagebox.showerror("Error", "Ingrese valores numéricos válidos para puntos salariales y valor por punto")
                return

            puntos_o_horas = float(puntos_texto)
            valor_punto = float(valor_punto_texto)
            salario_mensual = puntos_o_horas * valor_punto
        
        else:  # Docente Ocasional
            # Obtener y validar los valores de docentes ocasionales
            horas_texto = entry_horas.get().strip()
            valor_hora_texto = entry_valor_hora.get().strip()

            if not horas_texto.replace(".", "").isdigit() or not valor_hora_texto.replace(".", "").isdigit():
                messagebox.showerror("Error", "Ingrese valores numéricos válidos para horas y valor por hora")
                return

            puntos_o_horas = float(horas_texto)
            valor_hora = float(valor_hora_texto)
            salario_mensual = puntos_o_horas * valor_hora * 4  # 4 semanas por mes
        
        # Registrar el salario en la nómina del mes correspondiente
        nomina_mensual[mes - 1] += salario_mensual
        resultado.set(f"Mes {mes}: ${salario_mensual:,.2f} contratado")

        # Agregar a la tabla
        docentes_contratados.append((mes, tipo_docente, puntos_o_horas, f"${salario_mensual:,.2f}"))
        actualizar_tabla()

    except ValueError:
        messagebox.showerror("Error", "Ingrese valores numéricos válidos")

def actualizar_tabla():
    """Limpia la tabla y vuelve a llenarla con los datos actualizados"""
    for row in tabla.get_children():
        tabla.delete(row)
    
    for docente in docentes_contratados:
        tabla.insert("", "end", values=docente)

def mostrar_grafica():
    if sum(nomina_mensual) == 0:
        messagebox.showerror("Error", "No hay datos para mostrar")
        return
    
    meses = list(range(1, 13))
    plt.plot(meses, nomina_mensual, marker='o', linestyle='-')
    plt.xlabel("Mes")
    plt.ylabel("Costo Nómina ($)")
    plt.title("Evolución de la Nómina Anual")
    plt.grid()
    plt.show()

# Crear ventana principal
root = tk.Tk()
root.title("Simulador de Nómina UPC")

# Variables de entrada
tipo_var = tk.StringVar(value="Planta")
entry_mes = tk.Entry(root)
entry_puntos = tk.Entry(root)
entry_valor_punto = tk.Entry(root)
entry_horas = tk.Entry(root)
entry_valor_hora = tk.Entry(root)

# Etiquetas
tk.Label(root, text="Mes de Contratación (1-12):").grid(row=0, column=0)
tk.Label(root, text="Tipo de Docente:").grid(row=1, column=0)
tk.Label(root, text="Puntos Salariales (Planta):").grid(row=2, column=0)
tk.Label(root, text="Valor por Punto:").grid(row=3, column=0)
tk.Label(root, text="Horas por Semana (Ocasional):").grid(row=4, column=0)
tk.Label(root, text="Valor por Hora:").grid(row=5, column=0)

# Posicionar entradas
entry_mes.grid(row=0, column=1)
tk.OptionMenu(root, tipo_var, "Planta", "Ocasional").grid(row=1, column=1)
entry_puntos.grid(row=2, column=1)
entry_valor_punto.grid(row=3, column=1)
entry_horas.grid(row=4, column=1)
entry_valor_hora.grid(row=5, column=1)

# Botones
resultado = tk.StringVar()
tk.Button(root, text="Contratar", command=contratar_profesor).grid(row=6, column=0, columnspan=2)
tk.Button(root, text="Mostrar Gráfica", command=mostrar_grafica).grid(row=7, column=0, columnspan=2)
tk.Label(root, textvariable=resultado).grid(row=8, column=0, columnspan=2)

# Tabla para mostrar los docentes contratados
tk.Label(root, text="Docentes Contratados:").grid(row=9, column=0, columnspan=2)

tabla = ttk.Treeview(root, columns=("Mes", "Tipo", "Puntos/Horas", "Salario"), show="headings")
tabla.heading("Mes", text="Mes", anchor=tk.CENTER)
tabla.heading("Tipo", text="Tipo", anchor=tk.CENTER)
tabla.heading("Puntos/Horas", text="Puntos/Horas", anchor=tk.CENTER)
tabla.heading("Salario", text="Salario", anchor=tk.CENTER)

# Posicionar la tabla
tabla.grid(row=10, column=0, columnspan=2)

# Ejecutar la aplicación
root.mainloop()
