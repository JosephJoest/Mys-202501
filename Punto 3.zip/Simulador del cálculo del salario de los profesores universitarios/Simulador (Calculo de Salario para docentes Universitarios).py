import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import os
# Crear la ventana principal
ventana = tk.Tk()
ventana.title("Calculo de Salario para los docentes Universitarios (Decreto 1279)")
ventana.geometry("1200x1080")  # Establecer un tamaño de ventana inicial

# Crear un frame principal con scrollbar
main_frame = tk.Frame(ventana)
main_frame.pack(fill=tk.BOTH, expand=1)

# Crear un canvas
canvas = tk.Canvas(main_frame)
canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=1)

# Añadir scrollbar al canvas
scrollbar = ttk.Scrollbar(main_frame, orient=tk.VERTICAL, command=canvas.yview)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

# Configurar el canvas para que use el scrollbar
canvas.configure(yscrollcommand=scrollbar.set)

# Crear otro frame dentro del canvas para contener los widgets
frame = tk.Frame(canvas)

# Añadir el frame al canvas y mantener referencia a la ventana creada
canvas_window = canvas.create_window((0, 0), window=frame, anchor="nw")

# Función para ajustar el scrollregion exactamente al contenido
def ajustar_canvas():
    # Actualizar los widgets para asegurar que tienen sus dimensiones correctas
    frame.update_idletasks()
    
    # Obtener el tamaño real del frame
    frame_width = frame.winfo_reqwidth()
    frame_height = frame.winfo_reqheight()
    
    # Actualizar el tamaño de la ventana del canvas para que coincida con el frame
    canvas.itemconfig(canvas_window, width=frame_width)
    
    # Configurar la región de desplazamiento para que coincida exactamente con el contenido
    canvas.configure(scrollregion=(0, 0, frame_width, frame_height))

# Vincular la función de ajuste a eventos de cambio de tamaño
frame.bind("<Configure>", lambda e: ajustar_canvas())

# Configurar el evento de la rueda del ratón para el desplazamiento
def _on_mousewheel(event):
    canvas.yview_scroll(int(-1*(event.delta/120)), "units")

canvas.bind_all("<MouseWheel>", _on_mousewheel)
#Variable del Sueldo Base

Valor_Punto=47450

#FUNCIONES PARA EL CALCULO DE PUNTOS
def Calcular():
    #VARIABLES
    Puntos_TitulosUniversitarios=0
    Puntos_TituloPosgrado=0
    Puntos_CategoriasEscalafon=0
    Puntos_ExperienciaCalificada=0
    Puntos_Productividad=0
    Puntos_Totales=0
    Salario_Total =0
    especializaciones_contadas = 0
    #CALCULOS
    # CALUCLO DE PUNTOS (TITULOS DE ESTUDIOS UNIVERSITARIOS)
    if titulo_seleccionado.get()=="Titulo_Medicinaymusica":
        Puntos_TitulosUniversitarios+=183
        input_tituloEP.config(state="disabled")
        input_tituloTIC.config(state="disabled")
        label_tituloGA.config(state="disabled")
        label_tituloOA.config(state="disabled")
        input_tituloCMHYO.config(state="normal")
    elif titulo_seleccionado.get()=="Otra_Area":
        Puntos_TitulosUniversitarios+=178
        input_tituloCMHYO.config(state="disabled")
        input_tituloEP.config(state="normal")
        input_tituloTIC.config(state="normal")
        label_tituloGA.config(state="normal")
        label_tituloOA.config(state="normal")
    #CALUCLO DE PUNTOS (TITULOS DE POSGRADO)
    #CLINICA EN MEDICINA HUMANNA
    if input_tituloCMHYO.get() != "":
        años_medicina = int(input_tituloCMHYO.get())
    else:
        años_medicina = 0
    if años_medicina == 0:
        Puntos_TituloPosgrado += 0
    elif años_medicina == 1:
        Puntos_TituloPosgrado += 15
        especializaciones_contadas += 1
    elif años_medicina == 2:
        Puntos_TituloPosgrado += 30
        especializaciones_contadas += 1
    elif años_medicina == 3:
        Puntos_TituloPosgrado += 45
        especializaciones_contadas += 1
    elif años_medicina == 4:
        Puntos_TituloPosgrado += 60
        especializaciones_contadas += 1
    elif años_medicina >= 5:
        Puntos_TituloPosgrado += 75
        especializaciones_contadas += 1

    if especializaciones_contadas < 2:
        campos_especializacion = [input_tituloOA.get(),input_tituloGA.get(), input_tituloEP.get(), input_tituloTIC.get()]
        max_otras_especializaciones = 1 if especializaciones_contadas == 1 else 2
        otras_procesadas = 0
    # OTRAS AREAS DE ESPECIALIZACION
    for campo in campos_especializacion:
        if campo != "" and otras_procesadas < max_otras_especializaciones:
            años = int(campo)
            if años == 1 or años == 2:
                Puntos_TituloPosgrado += 20
            elif años == 3:
                Puntos_TituloPosgrado += 30
            elif años == 4: 
                Puntos_TituloPosgrado += 40
            elif años >= 5:  # Para 3, 4, 5 o más años
                Puntos_TituloPosgrado += 50  
            # Incrementar contadores
            otras_procesadas += 1
            especializaciones_contadas += 1
            # Salir si ya alcanzamos el límite total
            if especializaciones_contadas >= 2:
                break

    #MAGISTER Y MAESTRIA
    if input_tituloMYM.get()=="":
        Puntos_TituloPosgrado += 0
    elif int(input_tituloMYM.get())==1:
        Puntos_TituloPosgrado += 40
    elif int(input_tituloMYM.get())>=2:
        Puntos_TituloPosgrado += 60


    if input_tituloMYM.get()=="":
        Puntos_TituloPosgrado += 0
    elif int(input_tituloMYM.get())==1 and especializaciones_contadas==1:
        Puntos_TituloPosgrado += 10
    elif int(input_tituloMYM.get())==1 and especializaciones_contadas==2:
        Puntos_TituloPosgrado += 20

    #DOCTORADO
    if doctorado_seleccionado.get() == -1:
            Puntos_TituloPosgrado += 0
    else:
        if input_tituloPHDD.get() == "1":
            # Un PhD
            if input_tituloMYM.get() == "":
                # PhD sin maestría
                Puntos_TituloPosgrado += 80
            else:
                # PhD con maestría
                Puntos_TituloPosgrado += 120
        elif input_tituloPHDD.get() == "2":
            # Dos PhD (con o sin maestría)
            Puntos_TituloPosgrado += 140

    #ASEGURAR QUE LOS PUNTOS DE POSGRADO NO PASEN DE 140
    while Puntos_TituloPosgrado>140:
        Puntos_TituloPosgrado-=1
    
    Puntos_TitulosUniversitarios = Puntos_TituloPosgrado

    #Categorías dentro del Escalafón Docente
    if categoria_seleccionada.get()=="Auxiliar":
        Puntos_CategoriasEscalafon+=37
    elif categoria_seleccionada.get()=="Asistente":
        Puntos_CategoriasEscalafon+=58
    elif categoria_seleccionada.get()=="Asociado":
        Puntos_CategoriasEscalafon+=74
    elif categoria_seleccionada.get()=="Titular":
        Puntos_CategoriasEscalafon+=96
    elif categoria_seleccionada.get()=="Instructor Universidad Nacional":
        Puntos_CategoriasEscalafon+=44

    #EXPERIENCIA CALIFICADA
    #EXPERIENCIA INVESTIGATIVA
    if input_ExpInv.get() == "":
        Puntos_ExperienciaCalificada += 0
    elif int(input_ExpInv.get()) >= 1 and regimen_seleccionado.get() == "Regimen Estandar":
        Puntos_ExperienciaCalificada += 6 * int(input_ExpInv.get())
    elif int(input_ExpInv.get()) >= 1 and regimen_seleccionado.get() == "Regimen Diferente":
        Años_RegimenDierente += int(input_ExpInv.get())

    if input_ExpDoc.get() == "":
        Puntos_ExperienciaCalificada += 0
    elif int(input_ExpDoc.get()) >= 1 and regimen_seleccionado.get() == "Regimen Estandar":
        Puntos_ExperienciaCalificada += 4 * int(input_ExpDoc.get())
    elif int(input_ExpDoc.get()) >= 1 and regimen_seleccionado.get() == "Regimen Diferente":
        Años_RegimenDierente += int(input_ExpDoc.get())

    if input_ExpPCDA.get() == "":
        Puntos_ExperienciaCalificada += 0
    elif int(input_ExpPCDA.get()) >= 1 and regimen_seleccionado.get() == "Regimen Estandar":
        Puntos_ExperienciaCalificada += 4 * int(input_ExpPCDA.get())
    elif int(input_ExpPCDA.get()) >= 1 and regimen_seleccionado.get() == "Regimen Diferente":
        Años_RegimenDierente += int(input_ExpPCDA.get())

    if input_ExpNoDoc.get() == "":
        Puntos_ExperienciaCalificada += 0
    elif int(input_ExpNoDoc.get()) >= 1 and regimen_seleccionado.get() == "Regimen Estandar":
        Puntos_ExperienciaCalificada += 3 * int(input_ExpNoDoc.get())
    elif int(input_ExpNoDoc.get()) >= 1 and regimen_seleccionado.get() == "Regimen Diferente":
        Años_RegimenDierente += int(input_ExpNoDoc.get())

    #Funcion para establecer limite de puntos
    def limite(puntos, maximo):
        return min(puntos, maximo)
        
    #LIMITES DE CADA CATEGORIA EN LA EXPERIENCIA CALIFICADA
    if regimen_seleccionado.get() == "Regimen Diferente":
        if categoria_seleccionada.get() == "Auxiliar":
            Puntos_ExperienciaCalificada = Años_RegimenDierente * 3
        elif categoria_seleccionada.get() == "Asistente":
            Puntos_ExperienciaCalificada = Años_RegimenDierente * 5
        elif categoria_seleccionada.get() == "Asociado":
            Puntos_ExperienciaCalificada = Años_RegimenDierente * 6
        elif categoria_seleccionada.get() == "Titular":
            Puntos_ExperienciaCalificada = Años_RegimenDierente * 7
        elif categoria_seleccionada.get() == "Instructor Universidad Nacional":
            Puntos_ExperienciaCalificada = Años_RegimenDierente * 4

    if regimen_seleccionado.get() == "Regimen Estandar":
        if categoria_seleccionada.get() == "Auxiliar":
            Puntos_ExperienciaCalificada = limite(Puntos_ExperienciaCalificada, 20)
        elif categoria_seleccionada.get() == "Asistente":
            Puntos_ExperienciaCalificada = limite(Puntos_ExperienciaCalificada, 45)
        elif categoria_seleccionada.get() == "Asociado" or categoria_seleccionada.get() == "Instructor Universidad Nacional":
            Puntos_ExperienciaCalificada = limite(Puntos_ExperienciaCalificada, 90)
        elif categoria_seleccionada.get() == "Titular":
            Puntos_ExperienciaCalificada = limite(Puntos_ExperienciaCalificada, 120)

    #PRODUCTIVIDAD ACADEMICA
    #Articulos
    if input_A1.get()=="" or input_A2.get()=="" or input_B.get()=="" or input_C.get()=="":
        Puntos_Productividad+=0
    if input_A1.get()!="" and int(input_A1.get())>=1:
        Puntos_Productividad+=15*int(input_A1.get())
    if input_A2.get()!="" and int(input_A2.get())>=1:
        Puntos_Productividad+=12*int(input_A2.get())
    if input_B.get()!="" and int(input_B.get())>=1:
        Puntos_Productividad+=8*int(input_B.get())
    if input_C.get()!="" and int(input_C.get())>=1:
        Puntos_Productividad+=3*int(input_C.get())

    #Articulos Cortos
    if input_A1C.get()=="" or input_A2C.get()=="" or input_BC.get()=="" or input_CC.get()=="":
        Puntos_Productividad+=0
    if input_A1C.get()!="" and int(input_A1C.get())>=1:
        Puntos_Productividad+=(15*int(input_A1C.get())*0.60)
    if input_A2C.get()!="" and int(input_A2C.get())>=1:
        Puntos_Productividad+=(12*int(input_A2C.get())*0.60)
    if input_BC.get()!="" and int(input_BC.get())>=1:
        Puntos_Productividad+=(8*int(input_BC.get())*0.60)
    if input_CC.get()!="" and int(input_CC.get())>=1:
        Puntos_Productividad+=(3*int(input_CC.get())*0.60)
        
    #Reportes
    if input_A1E.get()=="" or input_A2E.get()=="" or input_BE.get()=="" or input_CE.get()=="":
        Puntos_Productividad+=0

    if input_A1E.get()!="" and int(input_A1E.get())>=1:
        Puntos_Productividad+=(15*int(input_A1E.get())*0.30)
    if input_A2E.get()!="" and int(input_A2E.get())>=1:
        Puntos_Productividad+=(12*int(input_A2E.get())*0.30)
    if input_BE.get()!="" and int(input_BE.get())>=1:
        Puntos_Productividad+=(8*int(input_BE.get())*0.30)
    if input_CE.get()!="" and int(input_CE.get())>=1:
        Puntos_Productividad+=(3*int(input_CE.get())*0.30)
    
    #PRODUCCION DE VIDEOS
    Total_obras = 0
    obras_puntos = []

    # Recolectar todas las obras con sus puntos
    if input_TI.get() != "" and int(input_TI.get()) >= 1:
        for _ in range(int(input_TI.get())):
            obras_puntos.append(12)

    if input_TN.get() != "" and int(input_TN.get()) >= 1:
        for _ in range(int(input_TN.get())):
            obras_puntos.append(7)

    if input_TID.get() != "" and int(input_TID.get()) >= 1:
        for _ in range(int(input_TID.get())):
            obras_puntos.append(9.6)  # 12 * 0.80

    if input_TND.get() != "" and int(input_TND.get()) >= 1:
        for _ in range(int(input_TND.get())):
            obras_puntos.append(5.6)  # 7 * 0.80

        # Ordenar y tomar solo las 5 mejores
        obras_puntos.sort(reverse=True)
        obras_puntos = obras_puntos[:5]

        # Sumar los puntos
        Puntos_Productividad += sum(obras_puntos)
        Total_obras = len(obras_puntos)

    #LIBROS
    #LIBRO LABOR DE INVESTIGACION
    if input_LaborInv.get()=="" or input_LibrosT.get()=="" or input_LEnsayos.get()=="" or input_Traduccion.get()=="" or input_Premios.get()=="" or input_Patentes.get()=="" or input_Innovacion.get()=="" or input_Adaptacion.get()=="" or input_Software.get()=="":
        Puntos_Productividad+=0

    if input_LaborInv.get()!="" and int(input_LaborInv.get())>=1:
        Puntos_Productividad+=20*int(input_LaborInv.get())
    #LIBRO DE TEXTO
    if input_LibrosT.get()!="" and int(input_LibrosT.get())>=1:
        Puntos_Productividad+=15*int(input_LibrosT.get())
    #LIBROS DE ENSAYO
    if input_LEnsayos.get()!="" and int(input_LEnsayos.get())>=1:
        Puntos_Productividad+=15*int(input_LEnsayos.get())
    #TRADUCCIONES
    if input_Traduccion.get()!="" and int(input_Traduccion.get())>=1:
        Puntos_Productividad+=15*int(input_Traduccion.get())
    #PREMIOS
    if input_Premios.get()!="" and int(input_Premios.get())>=1:
        Puntos_Productividad+=15*int(input_Premios.get())
    #PATENTES
    if input_Patentes.get()!="" and int(input_Patentes.get())>=1:
        Puntos_Productividad+=25*int(input_Patentes.get())
    #ADAPTACION TECNICA
    if input_Innovacion.get()!="" and int(input_Innovacion.get())>=1:
        Puntos_Productividad+=15
    if input_Adaptacion.get()!="" and int(input_Adaptacion.get())>=1:
        Puntos_Productividad+=8
    #PRODUCCION DE SOFTWARE
    if input_Software.get()!="" and int(input_Software.get())>=1:
        Puntos_Productividad+=15

    # OBRAS ARTISTICAS
    # OBRAS CREACION ORIGINAL
    Total_obras_artisticas = 0
    obras_artisticas_puntos = []

    # OBRAS CREACION ORIGINAL
    if input_ObrasI.get() != "" and int(input_ObrasI.get()) >= 1:
        for _ in range(int(input_ObrasI.get())):
            obras_artisticas_puntos.append(20)
            Total_obras_artisticas += 1

    if input_ObrasN.get() != "" and int(input_ObrasN.get()) >= 1:
        for _ in range(int(input_ObrasN.get())):
            obras_artisticas_puntos.append(14)
            Total_obras_artisticas += 1

    # OBRAS COMPLEMENTARIAS
    if input_ObrasAI.get() != "" and int(input_ObrasAI.get()) >= 1:
        for _ in range(int(input_ObrasAI.get())):
            obras_artisticas_puntos.append(12)
            Total_obras_artisticas += 1

    if input_ObrasAN.get() != "" and int(input_ObrasAN.get()) >= 1:
        for _ in range(int(input_ObrasAN.get())):
            obras_artisticas_puntos.append(8)
            Total_obras_artisticas += 1

    # INTERPRETACION
    if input_ObrasIA.get() != "" and int(input_ObrasIA.get()) >= 1:
        for _ in range(int(input_ObrasIA.get())):
            obras_artisticas_puntos.append(14)
            Total_obras_artisticas += 1

    if input_ObrasIAN.get() != "" and int(input_ObrasIAN.get()) >= 1:
        for _ in range(int(input_ObrasIAN.get())):
            obras_artisticas_puntos.append(8)
            Total_obras_artisticas += 1

    # Ordenar y tomar solo las 5 mejores si hay más de 5
    obras_artisticas_puntos.sort(reverse=True)
    if len(obras_artisticas_puntos) > 5:
        obras_artisticas_puntos = obras_artisticas_puntos[:5]

    # Sumar los puntos
    Puntos_Productividad = sum(obras_artisticas_puntos)  # Inicializar la variable

    # Función para calcular puntaje según número de autores
    def calcular_puntaje_por_autores(puntaje_base, num_autores):
        if num_autores <= 3:
            # Hasta 3 autores: cada uno recibe el puntaje total
            return puntaje_base
        elif num_autores <= 5:
            # De 4 a 5 autores: cada uno recibe la mitad del puntaje
            return puntaje_base / 2
        else:
            # 6 o más autores: cada uno recibe el puntaje dividido por la mitad del número de autores
            return puntaje_base / (num_autores / 2)

    # Función para asignar puntos por producción
    def asignar_puntos_produccion(tipo_produccion, puntaje_base, num_autores):
        # Calcular puntaje ajustado según número de autores
        puntaje_ajustado = calcular_puntaje_por_autores(puntaje_base, num_autores)
        
        # Retornar el puntaje ajustado
        return puntaje_ajustado

    #Establecer los Limites de Productividad Academica
    Puntos_Productividad+=calcular_puntos_productividad(entry_frames_dict)
    if categoria_seleccionada.get()=="Auxiliar":
        Puntos_Productividad = limite(Puntos_Productividad,80)
    elif categoria_seleccionada.get()=="Asistente":
        Puntos_Productividad =limite(Puntos_Productividad,160)
    elif categoria_seleccionada.get()=="Asociado" or categoria_seleccionada.get()=="Instructor Universidad Nacional":
        Puntos_Productividad =limite(Puntos_Productividad,320)
    elif categoria_seleccionada.get()=="Titular":
        Puntos_Productividad =limite(Puntos_Productividad,540)
    elif categoria_seleccionada.get()=="Instructor Universidad Nacional":
        Puntos_Productividad =limite(Puntos_Productividad,110)

    Puntos_Totales+=Puntos_TitulosUniversitarios + Puntos_CategoriasEscalafon + Puntos_Productividad + Puntos_ExperienciaCalificada
    Salario_Total+=Puntos_Totales*Valor_Punto

    #ENTRADAS
    #TITULOS UNIVERSITARIOS
    #IMPRIMIR RESULTADOS
    print("PUNTOS")
    print("Por titulos de estudio universitarios: ",Puntos_TitulosUniversitarios)
    print("Por Categoria: ",Puntos_CategoriasEscalafon)
    print("Por Experiencia: ",Puntos_ExperienciaCalificada)
    print("Por Productividad: ",Puntos_Productividad)
    print("TOTAL DE PUNTOS:",Puntos_Totales)
    print("SALARIO TOTAL: ",Salario_Total)

def actualizar_estado(*args):
    #Función que se ejecuta automáticamente cuando cambia la selección del título.
    #Habilita o deshabilita las casillas en las especializaciones dependiendo la eleccion
    if titulo_seleccionado.get() == "Titulo_Medicinaymusica":
        label_tituloEP.config(state="disabled")
        label_tituloTIC.config(state="disabled")
        label_tituloGA.config(state="disabled")
        label_tituloOA.config(state="disabled")
        input_tituloEP.config(state="disabled")
        input_tituloTIC.config(state="disabled")
        input_tituloGA.config(state="disabled")
        input_tituloOA.config(state="disabled")
        input_tituloCMHYO.config(state="normal")
        label_tituloCMHYO.config(state="normal")
    elif titulo_seleccionado.get() == "Otra_Area":
        label_tituloCMHYO.config(state="disabled")
        input_tituloCMHYO.config(state="disabled")
        input_tituloEP.config(state="normal")
        input_tituloTIC.config(state="normal")
        input_tituloGA.config(state="normal")
        input_tituloOA.config(state="normal")
        label_tituloEP.config(state="normal")
        label_tituloTIC.config(state="normal")
        label_tituloGA.config(state="normal")
        label_tituloOA.config(state="normal")

def actualizar_PHDD(*args):
    if input_tituloPHDD.get()!="":  # Si hay texto en el Entry
        radio_tituloPHDD.config(state="normal")
    else:
        radio_tituloPHDD.config(state="disabled")

        

# Variables para los botones de radio
titulo_seleccionado = tk.StringVar(value=-1)  # Almacena el valor seleccionado
titulo_seleccionado.trace_add("write", actualizar_estado)
categoria_seleccionada = tk.StringVar(value=-1)
regimen_seleccionado = tk.StringVar(value=-1)
doctorado_seleccionado = tk.StringVar(value=-1)
entrada_texto = tk.StringVar()
entrada_texto.trace_add("write", actualizar_PHDD)

# TITULOS DE ESTUDIOS UNIVERSITARIOS
label_tituloestudiosuniversitarios = tk.Label(frame, text="TITULOS DE ESTUDIOS UNIVERSITARIOS",font=("Arial", 12, "bold"))
label_tituloestudiosuniversitarios.grid(row=0, column=0, padx=10, pady=10)

radio_tituloMHYCM = tk.Radiobutton(frame, text="Título de pregrado en medicina humana  o composición musical", variable=titulo_seleccionado,value="Titulo_Medicinaymusica")
radio_tituloMHYCM.grid(row=1, column=0, padx=10, pady=5, sticky="w")

radio_tituloOA = tk.Radiobutton(frame, text="En otra Area", variable=titulo_seleccionado,value="Otra_Area")
radio_tituloOA.grid(row=2, column=0, padx=10, pady=5, sticky="w")

# TITULOS DE POSGRADO
label_tituloPos = tk.Label(frame, text="TITULOS DE POSGRADO",font=("Arial", 12, "bold"))
label_tituloPos.grid(row=3, column=0, padx=10, pady=10)

label_tituloEP = tk.Label(frame, text="Especializaciones (2 Maximo)",font=("Arial", 10, "bold"))
label_tituloEP.grid(row=4, column=0, padx=10, pady=10, sticky="w")

label_tituloCMHYO = tk.Label(frame, text="Clínicas en Medicina Humana y Odontología")
label_tituloCMHYO.grid(row=5, column=0, padx=10, pady=10, sticky="w")

input_tituloCMHYO = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
input_tituloCMHYO.grid(row=5, column=1, padx=10, pady=10,)
tk.Label(frame, text="Años cursados",font=("Arial", 10, "bold")).grid(row=5, column=2, padx=10, pady=10)

#OTRA AREA
label_tituloEP = tk.Label(frame, text="Educación y Pedagogía Universitaria")
label_tituloEP.grid(row=6, column=0, padx=10, pady=10, sticky="w")

input_tituloEP = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
input_tituloEP.grid(row=6, column=1, padx=10, pady=10,)
tk.Label(frame, text="Años cursados",font=("Arial", 10, "bold")).grid(row=6, column=2, padx=10, pady=10)

label_tituloTIC = tk.Label(frame, text="Tecnologías Educativas y Educación Virtual")
label_tituloTIC.grid(row=7, column=0, padx=10, pady=10, sticky="w")

input_tituloTIC = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
input_tituloTIC.grid(row=7, column=1, padx=10, pady=10,)
tk.Label(frame, text="Años cursados",font=("Arial", 10, "bold")).grid(row=7, column=2, padx=10, pady=10)

label_tituloGA = tk.Label(frame, text="Gestión y Administración Educativa")
label_tituloGA.grid(row=8, column=0, padx=10, pady=10, sticky="w")

input_tituloGA = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
input_tituloGA.grid(row=8, column=1, padx=10, pady=10,)
tk.Label(frame, text="Años cursados",font=("Arial", 10, "bold")).grid(row=8, column=2, padx=10, pady=10)

label_tituloOA = tk.Label(frame, text="Otra Area")
label_tituloOA.grid(row=9, column=0, padx=10, pady=10, sticky="w")

input_tituloOA = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
input_tituloOA.grid(row=9, column=1, padx=10, pady=10,)
tk.Label(frame, text="Años cursados",font=("Arial", 10, "bold")).grid(row=9, column=2, padx=10, pady=10)

label_tituloMYM = tk.Label(frame, text="Magister o Maestria",font=("Arial", 10, "bold"))
label_tituloMYM.grid(row=10, column=0, padx=10, pady=10, sticky="w")

input_tituloMYM = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
input_tituloMYM.grid(row=10, column=1, padx=10, pady=10)
tk.Label(frame, text="Titulos Obtenidos",font=("Arial", 10, "bold")).grid(row=10, column=2, padx=10, pady=10)

label_tituloPHDD = tk.Label(frame, text=" título de Ph. D. o Doctorado",font=("Arial", 10, "bold"))
label_tituloPHDD.grid(row=11, column=0, padx=10, pady=10, sticky="w")

input_tituloPHDD = tk.Entry(frame,highlightthickness=1, highlightbackground="black",textvariable=entrada_texto)
input_tituloPHDD.grid(row=11, column=1, padx=10, pady=10)
tk.Label(frame, text="Titulos Obtenidos",font=("Arial", 10, "bold")).grid(row=11, column=2, padx=10, pady=10)

radio_tituloPHDD = tk.Radiobutton(frame, text="Título de Doctorado obtenido después de 1998", variable=doctorado_seleccionado,state="disabled")
radio_tituloPHDD.grid(row=11, column=3, padx=10, pady=5)

#CATEGORIAS DENTRO DEL ESCALAFON DOCENTE
label_categorias = tk.Label(frame, text="CATEGORIAS DENTRO DEL ESCALAFON DOCENTE",font=("Arial", 12, "bold"))
label_categorias.grid(row=12, column=0, padx=10, pady=10)

radio_Auxiliar = tk.Radiobutton(frame, text=" Instructor / Profesor Auxiliar / Instructor Asistente", variable=categoria_seleccionada, value="Auxiliar")
radio_Auxiliar.grid(row=13, column=0, padx=10, pady=5, sticky="w")

radio_Asistente = tk.Radiobutton(frame, text="Asistente", variable=categoria_seleccionada, value="Asistente")
radio_Asistente.grid(row=14, column=0, padx=10, pady=5, sticky="w")

radio_Asociado = tk.Radiobutton(frame, text="Asociado", variable=categoria_seleccionada, value="Asociado")
radio_Asociado.grid(row=15, column=0, padx=10, pady=5, sticky="w")

radio_Titular = tk.Radiobutton(frame, text="Titular", variable=categoria_seleccionada, value="Titular")
radio_Titular.grid(row=16, column=0, padx=10, pady=5, sticky="w")

radio_Inst_Univ = tk.Radiobutton(frame, text="Instructor Asociado (Universidad Nacional)", variable=categoria_seleccionada, value="Instructor Universidad Nacional")
radio_Inst_Univ.grid(row=17, column=0, padx=10, pady=5, sticky="w")

#CALUCLO DE PUNTOS (CATEGORIAS DENTRO DEL ESCALAFON DOCENTE)
# EXPERIENCIA CALIFICADAR
label_ExpCalificada = tk.Label(frame, text="EXPERIENCIA CALIFICADA",font=("Arial", 12, "bold"))
label_ExpCalificada.grid(row=18, column=0, padx=10, pady=10)

radio_RE = tk.Radiobutton(frame, text="Regimen Estandar", variable=regimen_seleccionado, value="Regimen Estandar",font=("Arial", 9, "bold"))
radio_RE.grid(row=19, column=0, padx=10, pady=5, sticky="w")

radio_RD = tk.Radiobutton(frame, text="Regimen Diferente", variable=regimen_seleccionado, value="Regimen Diferente",font=("Arial", 9, "bold"))
radio_RD.grid(row=20, column=0, padx=10, pady=5, sticky="w")

label_ExpInv= tk.Label(frame, text="Experiencia Investigativa")
label_ExpInv.grid(row=21, column=0, padx=10, pady=10, sticky="w")

input_ExpInv = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
input_ExpInv.grid(row=21, column=1, padx=10, pady=10)
tk.Label(frame, text="Años",font=("Arial", 10, "bold")).grid(row=21, column=2, padx=10, pady=10)

label_ExpDoc= tk.Label(frame, text="Experiencia en Docencia")
label_ExpDoc.grid(row=22, column=0, padx=10, pady=10, sticky="w")

input_ExpDoc = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
input_ExpDoc.grid(row=22, column=1, padx=10, pady=10)
tk.Label(frame, text="Años",font=("Arial", 10, "bold")).grid(row=22, column=2, padx=10, pady=10)

label_ExpPCDA= tk.Label(frame, text="Experiencia profesional calificada en cargos de dirección académica")
label_ExpPCDA.grid(row=23, column=0, padx=10, pady=10, sticky="w")

input_ExpPCDA = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
input_ExpPCDA.grid(row=23, column=1, padx=10, pady=10)
tk.Label(frame, text="Años",font=("Arial", 10, "bold")).grid(row=23, column=2, padx=10, pady=10)

label_ExpNoDoc= tk.Label(frame, text="Experiencia profesional calificada diferente a la docente")
label_ExpNoDoc.grid(row=24, column=0, padx=10, pady=10, sticky="w")

input_ExpNoDoc = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
input_ExpNoDoc.grid(row=24, column=1, padx=10, pady=10)
tk.Label(frame, text="Años",font=("Arial", 10, "bold")).grid(row=24, column=2, padx=10, pady=10)

#CALUCLO DE PUNTOS (EXPERIENCIA CALIFICADAR)
#PRODUCTIVIDAD ACADEMICA 
label_Productividad = tk.Label(frame, text="PRODUCTIVIDAD ACADEMICA - RECONOCIMIENTOS EN REVISTAS ESPECIALIZADAS.",font=("Arial", 12, "bold"))
label_Productividad.grid(row=25, column=0, padx=10, pady=10)

label_Reconocimiento = tk.Label(frame, text="Reconocimiento en Revistas Especializadas",font=("Arial", 11, "bold"))
label_Reconocimiento.grid(row=26, column=0, padx=10, pady=10)

def crear_campos_autores(parent_frame, cantidad, row_start, col, tipo_producto):
    """Crea campos dinámicos para ingresar datos de autores"""
    frames = []
    if cantidad > 0:
        # Limitar a máximo 10 autores
        cantidad = min(int(cantidad), 10)
        
        # Crear un subframe para contener todos los campos de autor
        autor_frame = tk.Frame(parent_frame, bd=1, relief="solid")
        autor_frame.grid(row=row_start, column=col, padx=10, pady=10, sticky="w")
        
        # Etiqueta para los autores
        tk.Label(autor_frame, text=f"Autores para {tipo_producto}", font=("Arial", 10, "bold")).grid(row=0, column=0, columnspan=2, padx=5, pady=5)
        
        # Crear campos para cada autor
        for i in range(cantidad):
            autor_label = tk.Label(autor_frame, text=f"Autor #{i+1}:")
            autor_label.grid(row=i+1, column=0, padx=5, pady=2, sticky="w")
            
            autor_entry = tk.Entry(autor_frame, highlightthickness=1, highlightbackground="black", width=30)
            autor_entry.grid(row=i+1, column=1, padx=5, pady=2)
            
            frames.append((autor_label, autor_entry))
    
    return frames

def calcular_puntos_por_autores(base_puntos, num_autores):
    """Calcula los puntos según el número de autores usando las reglas especificadas"""
    if num_autores <= 3:
        return base_puntos  # Puntaje completo
    elif 4 <= num_autores <= 5:
        return base_puntos / 2  # Mitad del puntaje
    else:  # 6 o más autores
        return base_puntos / (num_autores / 2)  # Puntaje dividido por la mitad del número de autores

def actualizar_campos_autores(entry, entry_frames, parent_frame, row, col, tipo_producto):
    """Actualiza los campos de autores cuando cambia la cantidad"""
    # Limpia todos los frames existentes
    for frame_tuple in entry_frames:
        for widget in frame_tuple:
            if widget and widget.winfo_exists():
                widget.destroy()
    
    entry_frames.clear()
    
    try:
        cantidad = int(entry.get())
        if cantidad > 0:
            nuevos_frames = crear_campos_autores(parent_frame, cantidad, row, col, tipo_producto)
            entry_frames.extend(nuevos_frames)
    except ValueError:
        pass

def setup_dynamic_entries(frame):
    global input_A1
    global input_A2
    global input_B
    global input_C
    global input_A1C
    global input_A2C
    global input_BC
    global input_CC
    global input_A1E
    global input_A2E
    global input_BE
    global input_CE
    global input_TI
    global input_TN
    global input_TID
    global input_TND
    global input_LaborInv
    global input_LibrosT
    global input_LEnsayos
    global input_Premios
    global input_Patentes
    global input_Traduccion
    global input_ObrasI
    global input_ObrasN
    global input_ObrasAI
    global input_ObrasAN
    global input_ObrasIA
    global input_ObrasIAN
    global input_Innovacion
    global input_Adaptacion
    global input_Software
    """Configura todas las entradas dinámicas para los productos académicos"""
    entry_frames_dict = {}  # Diccionario para almacenar los frames de entrada por tipo
    
    # ARTÍCULOS
    label_Articulo = tk.Label(frame, text="ARTICULOS", font=("Arial", 11, "bold"))
    label_Articulo.grid(row=27, column=0, padx=10, pady=10, sticky="w")

    # A1
    labelA1 = tk.Label(frame, text="Trabajos, ensayos y artículos de carácter científico, técnico, artístico, humanístico o pedagógico publicados en revistas del tipo A1")
    labelA1.grid(row=28, column=0, padx=10, pady=10, sticky="w")

    input_A1 = tk.Entry(frame, highlightthickness=1, highlightbackground="black")
    input_A1.grid(row=28, column=1, padx=10, pady=10)
    tk.Label(frame, text="Articulos Publicados", font=("Arial", 10, "bold")).grid(row=28, column=2, padx=10, pady=10)
    
    entry_frames_dict['A1'] = []
    input_A1.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_A1, entry_frames_dict['A1'], frame, 28, 3, "Artículos A1"))

    # A2
    labelA2 = tk.Label(frame, text="Trabajos, ensayos y artículos de carácter científico, técnico, artístico, humanístico o pedagógico publicados en revistas del tipo A2")
    labelA2.grid(row=29, column=0, padx=10, pady=10, sticky="w")

    input_A2 = tk.Entry(frame, highlightthickness=1, highlightbackground="black")
    input_A2.grid(row=29, column=1, padx=10, pady=10)
    tk.Label(frame, text="Articulos Publicados", font=("Arial", 10, "bold")).grid(row=29, column=2, padx=10, pady=10)
    
    entry_frames_dict['A2'] = []
    input_A2.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_A2, entry_frames_dict['A2'], frame, 29, 3, "Artículos A2"))

    # B
    labelB = tk.Label(frame, text="Trabajos, ensayos y artículos de carácter científico, técnico, artístico, humanístico o pedagógico publicados en revistas del tipo B")
    labelB.grid(row=30, column=0, padx=10, pady=10, sticky="w")

    input_B = tk.Entry(frame, highlightthickness=1, highlightbackground="black")
    input_B.grid(row=30, column=1, padx=10, pady=10)
    tk.Label(frame, text="Articulos Publicados", font=("Arial", 10, "bold")).grid(row=30, column=2, padx=10, pady=10)
    
    entry_frames_dict['B'] = []
    input_B.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_B, entry_frames_dict['B'], frame, 30, 3, "Artículos B"))

    # C
    labelC = tk.Label(frame, text="Trabajos, ensayos y artículos de carácter científico, técnico, artístico, humanístico o pedagógico publicados en revistas del tipo C")
    labelC.grid(row=31, column=0, padx=10, pady=10, sticky="w")

    input_C = tk.Entry(frame, highlightthickness=1, highlightbackground="black")
    input_C.grid(row=31, column=1, padx=10, pady=10)
    tk.Label(frame, text="Articulos Publicados", font=("Arial", 10, "bold")).grid(row=31, column=2, padx=10, pady=10)
    
    entry_frames_dict['C'] = []
    input_C.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_C, entry_frames_dict['C'], frame, 31, 3, "Artículos C"))

    # ARTICULOS CORTOS
    label_ArticuloCorto = tk.Label(frame, text="ARTICULOS CORTOS", font=("Arial", 11, "bold"))
    label_ArticuloCorto.grid(row=32, column=0, padx=10, pady=10, sticky="w")

    # A1C
    labelA1C = tk.Label(frame, text="Trabajos, ensayos y artículos de carácter científico, técnico, artístico, humanístico o pedagógico publicados en revistas del tipo A1")
    labelA1C.grid(row=33, column=0, padx=10, pady=10, sticky="w")

    input_A1C = tk.Entry(frame, highlightthickness=1, highlightbackground="black")
    input_A1C.grid(row=33, column=1, padx=10, pady=10)
    tk.Label(frame, text="Articulos Publicados", font=("Arial", 10, "bold")).grid(row=33, column=2, padx=10, pady=10)
    
    entry_frames_dict['A1C'] = []
    input_A1C.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_A1C, entry_frames_dict['A1C'], frame, 33, 3, "Artículos Cortos A1"))

    # Continuar con los demás campos de manera similar
    # A2C
    labelA2C = tk.Label(frame, text="Trabajos, ensayos y artículos de carácter científico, técnico, artístico, humanístico o pedagógico publicados en revistas del tipo A2")
    labelA2C.grid(row=34, column=0, padx=10, pady=10, sticky="w")

    input_A2C = tk.Entry(frame, highlightthickness=1, highlightbackground="black")
    input_A2C.grid(row=34, column=1, padx=10, pady=10)
    tk.Label(frame, text="Articulos Publicados", font=("Arial", 10, "bold")).grid(row=34, column=2, padx=10, pady=10)
    
    entry_frames_dict['A2C'] = []
    input_A2C.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_A2C, entry_frames_dict['A2C'], frame, 34, 3, "Artículos Cortos A2"))

    # BC
    labelBC = tk.Label(frame, text="Trabajos, ensayos y artículos de carácter científico, técnico, artístico, humanístico o pedagógico publicados en revistas del tipo B")
    labelBC.grid(row=35, column=0, padx=10, pady=10, sticky="w")

    input_BC = tk.Entry(frame, highlightthickness=1, highlightbackground="black")
    input_BC.grid(row=35, column=1, padx=10, pady=10)
    tk.Label(frame, text="Articulos Publicados", font=("Arial", 10, "bold")).grid(row=35, column=2, padx=10, pady=10)
    
    entry_frames_dict['BC'] = []
    input_BC.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_BC, entry_frames_dict['BC'], frame, 35, 3, "Artículos Cortos B"))

    # CC
    labelCC = tk.Label(frame, text="Trabajos, ensayos y artículos de carácter científico, técnico, artístico, humanístico o pedagógico publicados en revistas del tipo C")
    labelCC.grid(row=36, column=0, padx=10, pady=10, sticky="w")

    input_CC = tk.Entry(frame, highlightthickness=1, highlightbackground="black")
    input_CC.grid(row=36, column=1, padx=10, pady=10)
    tk.Label(frame, text="Articulos Publicados", font=("Arial", 10, "bold")).grid(row=36, column=2, padx=10, pady=10)
    
    entry_frames_dict['CC'] = []
    input_CC.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_CC, entry_frames_dict['CC'], frame, 36, 3, "Artículos Cortos C"))

    # REPORTES DE CASO
    label_Reportes = tk.Label(frame, text="REPORTES DE CASO O REVISIONES DE TEMA O CARTAS AL EDITOR O EDITORES", font=("Arial", 11, "bold"))
    label_Reportes.grid(row=37, column=0, padx=10, pady=10, sticky="w")

    # A1E
    labelA1E = tk.Label(frame, text="Trabajos, ensayos y artículos de carácter científico, técnico, artístico, humanístico o pedagógico publicados en revistas del tipo A1")
    labelA1E.grid(row=38, column=0, padx=10, pady=10, sticky="w")

    input_A1E = tk.Entry(frame, highlightthickness=1, highlightbackground="black")
    input_A1E.grid(row=38, column=1, padx=10, pady=10)
    tk.Label(frame, text="Articulos Publicados", font=("Arial", 10, "bold")).grid(row=38, column=2, padx=10, pady=10)
    
    entry_frames_dict['A1E'] = []
    input_A1E.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_A1E, entry_frames_dict['A1E'], frame, 38, 3, "Reportes A1"))

    # Continuar configurando los demás campos...
    # (El código se repite para todas las demás entradas, siguiendo el mismo patrón)
    
    # Continúo con algunos más como ejemplo para mostrar el patrón:
    
    # A2E
    labelA2E = tk.Label(frame, text="Trabajos, ensayos y artículos de carácter científico, técnico, artístico, humanístico o pedagógico publicados en revistas del tipo A2")
    labelA2E.grid(row=39, column=0, padx=10, pady=10, sticky="w")

    input_A2E = tk.Entry(frame, highlightthickness=1, highlightbackground="black")
    input_A2E.grid(row=39, column=1, padx=10, pady=10)
    tk.Label(frame, text="Articulos Publicados", font=("Arial", 10, "bold")).grid(row=39, column=2, padx=10, pady=10)
    
    entry_frames_dict['A2E'] = []
    input_A2E.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_A2E, entry_frames_dict['A2E'], frame, 39, 3, "Reportes A2"))

    labelBE= tk.Label(frame, text="Trabajos, ensayos y artículos de carácter científico, técnico, artístico, humanístico o pedagógico publicados en revistas del tipo B")
    labelBE.grid(row=40, column=0, padx=10, pady=10, sticky="w")

    input_BE = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_BE.grid(row=40, column=1, padx=10, pady=10)
    tk.Label(frame, text="Articulos Publicados",font=("Arial", 10, "bold")).grid(row=40, column=2, padx=10, pady=10)

    entry_frames_dict['BE'] = []
    input_BE.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_BE, entry_frames_dict['BE'], frame, 40, 3, "Reportes BE"))

    labelCE= tk.Label(frame, text="Trabajos, ensayos y artículos de carácter científico, técnico, artístico, humanístico o pedagógico publicados en revistas del tipo C")
    labelCE.grid(row=41, column=0, padx=10, pady=10, sticky="w")

    input_CE = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_CE.grid(row=41, column=1, padx=10, pady=10)
    tk.Label(frame, text="Articulos Publicados",font=("Arial", 10, "bold")).grid(row=41, column=2, padx=10, pady=10)

    entry_frames_dict['CE'] = []
    input_CE.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_CE, entry_frames_dict['CE'], frame, 41, 3, "Reportes CE"))    
    # ... (Configurar los demás campos siguiendo el mismo patrón)
    
    # PRODUCCIÓN DE VIDEOS
    label_Produccion = tk.Label(frame, text="PRODUCCIÓN DE VIDEOS, CINEMATOGRÁFICAS O FONOGRÁFICAS", font=("Arial", 11, "bold"))
    label_Produccion.grid(row=42, column=0, padx=10, pady=10, sticky="w")

    # TI
    labelTI = tk.Label(frame, text="Trabajos científicos, técnicos, artísticos o pedagógicos en video, cine o audio de impacto internacional.")
    labelTI.grid(row=43, column=0, padx=10, pady=10, sticky="w")

    input_TI = tk.Entry(frame, highlightthickness=1, highlightbackground="black")
    input_TI.grid(row=43, column=1, padx=10, pady=10)
    tk.Label(frame, text="Trabajos Producidos", font=("Arial", 10, "bold")).grid(row=43, column=2, padx=10, pady=10)
    
    entry_frames_dict['TI'] = []
    input_TI.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_TI, entry_frames_dict['TI'], frame, 43, 3, "Trabajos Internacionales"))

    labelTN= tk.Label(frame, text="Trabajos científicos, técnicos, artísticos o pedagógicos en video, cine o audio de impacto nacional.")
    labelTN.grid(row=44, column=0, padx=10, pady=10, sticky="w")

    input_TN = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_TN.grid(row=44, column=1, padx=10, pady=10)
    tk.Label(frame, text="Trabajos Producidos",font=("Arial", 10, "bold")).grid(row=44, column=2, padx=10, pady=10)

    entry_frames_dict['TN'] = []
    input_TN.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_TN, entry_frames_dict['TN'], frame, 43, 3, "Trabajos Nacionales"))

    labelTID= tk.Label(frame, text="Trabajos científicos, técnicos, artísticos o pedagógicos en video, cine o audio de impacto internacional (Documental).")
    labelTID.grid(row=45, column=0, padx=10, pady=10, sticky="w")

    input_TID = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_TID.grid(row=45, column=1, padx=10, pady=10)
    tk.Label(frame, text="Trabajos Producidos",font=("Arial", 10, "bold")).grid(row=45, column=2, padx=10, pady=10)

    entry_frames_dict['TID'] = []
    input_TID.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_TID, entry_frames_dict['TID'], frame, 43, 3, "Trabajos Internacionales"))

    labelTND= tk.Label(frame, text="Trabajos científicos, técnicos, artísticos o pedagógicos en video, cine o audio de impacto nacional (Documental).")
    labelTND.grid(row=46, column=0, padx=10, pady=10, sticky="w")

    input_TND = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_TND.grid(row=46, column=1, padx=10, pady=10)
    tk.Label(frame, text="Trabajos Producidos",font=("Arial", 10, "bold")).grid(row=46, column=2, padx=10, pady=10)

    entry_frames_dict['TND'] = []
    input_TND.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_TND, entry_frames_dict['TND'], frame, 43, 3, "Trabajos Nacionales"))
    
    # LIBROS QUE RESULTEN DE UNA LABOR DE INVESTIGACIÓN
    label_LaborInv = tk.Label(frame, text="LIBROS QUE RESULTEN DE UNA LABOR DE INVESTIGACIÓN", font=("Arial", 11, "bold"))
    label_LaborInv.grid(row=47, column=0, padx=10, pady=10, sticky="w")

    input_LaborInv = tk.Entry(frame, highlightthickness=1, highlightbackground="black")
    input_LaborInv.grid(row=47, column=1, padx=10, pady=10)
    tk.Label(frame, text="Libros", font=("Arial", 10, "bold")).grid(row=47, column=2, padx=10, pady=10)
    
    entry_frames_dict['LaborInv'] = []
    input_LaborInv.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_LaborInv, entry_frames_dict['LaborInv'], frame, 47, 3, "Libros de Investigación"))
    
    # (Continuar con el resto de las entradas...)
    #LIBROS DE TEXTO.
    label_Libros = tk.Label(frame, text="LIBROS DE TEXTO",font=("Arial", 11, "bold"))
    label_Libros.grid(row=48, column=0, padx=10, pady=10,sticky="w")

    label_LibrosT = tk.Label(frame, text="Libros de texto que cumplan las condiciones exigidas en el Capítulo V de el decreto Decreto 1279")
    label_LibrosT.grid(row=49, column=0, padx=10, pady=10,sticky="w")

    input_LibrosT = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_LibrosT.grid(row=49, column=1, padx=10, pady=10)
    tk.Label(frame,text="Libros",font=("Arial", 10, "bold")).grid(row=49, column=2, padx=10, pady=10)

    entry_frames_dict['LibrosT'] = []
    input_LibrosT.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_LibrosT, entry_frames_dict['LibrosT'], frame, 49, 3, "Libros de Texto"))

    #LIBROS DE ENSAYO
    label_Ensayos = tk.Label(frame, text="LIBROS DE ENSAYO",font=("Arial", 11, "bold"))
    label_Ensayos.grid(row=50, column=0, padx=10, pady=10,sticky="w")

    label_LEnsayos = tk.Label(frame, text="Libros de ensayo que cumplan las condiciones exigidas en el Capítulo V de el decreto Decreto 1279")
    label_LEnsayos.grid(row=51, column=0, padx=10, pady=10,sticky="w")

    input_LEnsayos = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_LEnsayos.grid(row=51, column=1, padx=10, pady=10)
    tk.Label(frame,text="Libros",font=("Arial", 10, "bold")).grid(row=51, column=2, padx=10, pady=10)

    entry_frames_dict['LEnsayos'] = []
    input_LEnsayos.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_LEnsayos, entry_frames_dict['LEnsayos'], frame, 51, 3, "Libros de Ensayo"))

    #PREMIOS NACIONALES E INTERNACIONALES. 
    label_Premios = tk.Label(frame, text="PREMIOS NACIONALES E INTERNACIONALES",font=("Arial", 11, "bold"))
    label_Premios.grid(row=52, column=0, padx=10, pady=10,sticky="w")

    input_Premios = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_Premios.grid(row=52, column=1, padx=10, pady=10)
    tk.Label(frame,text="Premios",font=("Arial", 10, "bold")).grid(row=52, column=2, padx=10, pady=10)

    entry_frames_dict['Premios'] = []
    input_Premios.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_Premios, entry_frames_dict['Premios'], frame, 52, 3, "Premios"))

    #PATENTES.
    label_Patentes = tk.Label(frame, text="PATENTES",font=("Arial", 11, "bold"))
    label_Patentes.grid(row=53, column=0, padx=10, pady=10,sticky="w")

    input_Patentes = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_Patentes.grid(row=53, column=1, padx=10, pady=10)
    tk.Label(frame,text="Patentes Totales",font=("Arial", 10, "bold")).grid(row=53, column=2, padx=10, pady=10)

    entry_frames_dict['Patentes'] = []
    input_Patentes.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_Patentes, entry_frames_dict['Patentes'], frame, 53, 3, "Patentes"))

    #TRADUCCIONES DE LIBROS. 
    label_Traduccion = tk.Label(frame, text="TRADUCCIONES DE LIBROS",font=("Arial", 11, "bold"))
    label_Traduccion.grid(row=54, column=0, padx=10, pady=10,sticky="w")

    label_Traduccion = tk.Label(frame, text="Libros de ensayo que cumplan las condiciones exigidas en el Capítulo V de el decreto Decreto 1279")
    label_Traduccion.grid(row=55, column=0, padx=10, pady=10,sticky="w")

    input_Traduccion = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_Traduccion.grid(row=55, column=1, padx=10, pady=10)
    tk.Label(frame,text="Libros",font=("Arial", 10, "bold")).grid(row=55, column=2, padx=10, pady=10)

    entry_frames_dict['Traduccion'] = []
    input_Traduccion.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_Traduccion, entry_frames_dict['Traduccion'], frame, 55, 3, "Traduccion de Libros"))

    #OBRAS ARTÍSTICAS.
    label_Obras = tk.Label(frame, text="OBRAS ARTÍSTICAS",font=("Arial", 11, "bold"))
    label_Obras.grid(row=56, column=0, padx=10, pady=10,sticky="w")

    label_ObrasA = tk.Label(frame, text="1.Obras de creación original artística",font=("Arial", 10, "bold"))
    label_ObrasA.grid(row=57, column=0, padx=10, pady=10,sticky="w")

    label_ObrasI = tk.Label(frame, text="De impacto o trascendencia internacional.")
    label_ObrasI.grid(row=58, column=0, padx=10, pady=10,sticky="w")

    input_ObrasI = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_ObrasI.grid(row=58, column=1, padx=10, pady=10)
    tk.Label(frame,text="Libros",font=("Arial", 10, "bold")).grid(row=58, column=2, padx=10, pady=10)

    entry_frames_dict['ObrasI'] = []
    input_ObrasI.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_ObrasI, entry_frames_dict['ObrasI'], frame, 58, 3, "Obras de impacto o trascendencia internacional"))

    label_ObrasN = tk.Label(frame, text="De impacto o trascendencia nacional.")
    label_ObrasN.grid(row=59, column=0, padx=10, pady=10,sticky="w")

    input_ObrasN = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_ObrasN.grid(row=59, column=1, padx=10, pady=10)
    tk.Label(frame,text="Libros",font=("Arial", 10, "bold")).grid(row=59, column=2, padx=10, pady=10)

    entry_frames_dict['ObrasN'] = []
    input_ObrasN.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_ObrasN, entry_frames_dict['ObrasN'], frame, 59, 3, "Obras de impacto o trascendencia nacional"))

    label_ObrasAC = tk.Label(frame, text="2. Obras de creación complementaria o de apoyo. ",font=("Arial", 10, "bold"))
    label_ObrasAC.grid(row=60, column=0, padx=10, pady=10,sticky="w")

    label_ObrasAI = tk.Label(frame, text="De impacto o trascendencia internacional.")
    label_ObrasAI.grid(row=61, column=0, padx=10, pady=10,sticky="w")

    input_ObrasAI = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_ObrasAI.grid(row=61, column=1, padx=10, pady=10)
    tk.Label(frame,text="Libros",font=("Arial", 10, "bold")).grid(row=61, column=2, padx=10, pady=10)

    entry_frames_dict['ObrasAI'] = []
    input_ObrasAI.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_ObrasAI, entry_frames_dict['ObrasAI'], frame, 61, 3, "Obras de impacto o trascendencia internacional"))

    label_ObrasAN = tk.Label(frame, text="De impacto o trascendencia nacional.")
    label_ObrasAN.grid(row=62, column=0, padx=10, pady=10,sticky="w")

    input_ObrasAN = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_ObrasAN.grid(row=62, column=1, padx=10, pady=10)
    tk.Label(frame,text="Libros",font=("Arial", 10, "bold")).grid(row=62, column=2, padx=10, pady=10)

    entry_frames_dict['ObrasAN'] = []
    input_ObrasAN.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_ObrasAN, entry_frames_dict['ObrasAN'], frame, 62, 3, "Obras de impacto o trascendencia nacional"))

    label_ObrasIC = tk.Label(frame, text="3.Interpretaciones artísticas",font=("Arial", 10, "bold"))
    label_ObrasIC.grid(row=63, column=0, padx=10, pady=10,sticky="w")

    label_ObrasIA = tk.Label(frame, text="De impacto o trascendencia internacional.")
    label_ObrasIA.grid(row=64, column=0, padx=10, pady=10,sticky="w")

    input_ObrasIA = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_ObrasIA.grid(row=64, column=1, padx=10, pady=10)
    tk.Label(frame,text="Libros",font=("Arial", 10, "bold")).grid(row=64, column=2, padx=10, pady=10)

    entry_frames_dict['ObrasIA'] = []
    input_ObrasIA.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_ObrasIA, entry_frames_dict['ObrasIA'], frame, 64, 3, "Obras de impacto o trascendencia internacional"))

    label_ObrasIAN = tk.Label(frame, text="De impacto o trascendencia nacional.")
    label_ObrasIAN.grid(row=65, column=0, padx=10, pady=10,sticky="w")

    input_ObrasIAN = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_ObrasIAN.grid(row=65, column=1, padx=10, pady=10)
    tk.Label(frame,text="Libros",font=("Arial", 10, "bold")).grid(row=65, column=2, padx=10, pady=10)

    entry_frames_dict['ObrasIAN'] = []
    input_ObrasIAN.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_ObrasIAN, entry_frames_dict['ObrasIAN'], frame, 65, 3, "Obras de impacto o trascendencia nacional"))

    #PRODUCCIÓN TÉCNICA. 
    label_Tecnico = tk.Label(frame, text="PRODUCCIÓN TÉCNICA",font=("Arial", 11, "bold"))
    label_Tecnico.grid(row=66, column=0, padx=10, pady=10,sticky="w")

    label_Innovacion = tk.Label(frame, text="Diseño de sistemas o procesos que constituyen una innovación tecnológica y que tienen impacto y aplicación")
    label_Innovacion.grid(row=67, column=0, padx=10, pady=10,sticky="w")

    input_Innovacion = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_Innovacion.grid(row=67, column=1, padx=10, pady=10)
    tk.Label(frame,text="Sistemas o Procesos hechos",font=("Arial", 10, "bold")).grid(row=67, column=2, padx=10, pady=10)

    entry_frames_dict['Innovacion'] = []
    input_Innovacion.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_Innovacion, entry_frames_dict['Innovacion'], frame, 67, 3, "Innovacion"))

    label_Adaptacion = tk.Label(frame, text="Diseño de sistemas o procesos que constituyen una adaptación tecnológica y que tienen impacto y aplicación")
    label_Adaptacion.grid(row=68, column=0, padx=10, pady=10,sticky="w")

    input_Adaptacion = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_Adaptacion.grid(row=68, column=1, padx=10, pady=10)
    tk.Label(frame,text="Sistemas o Procesos hechos",font=("Arial", 10, "bold")).grid(row=68, column=2, padx=10, pady=10)

    entry_frames_dict['Adaptacion'] = []
    input_Adaptacion.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_Adaptacion, entry_frames_dict['Adaptacion'], frame, 68, 3, "Adaptacion"))

    #PRODUCCION DE SOFTWARE
    label_Software = tk.Label(frame, text="PRODUCCIÓN DE SOFTWARES",font=("Arial", 11, "bold"))
    label_Software.grid(row=69, column=0, padx=10, pady=10,sticky="w")

    input_Software = tk.Entry(frame,highlightthickness=1, highlightbackground="black")
    input_Software.grid(row=69, column=1, padx=10, pady=10)
    tk.Label(frame,text="Sistemas hechos",font=("Arial", 10, "bold")).grid(row=69, column=2, padx=10, pady=10)

    entry_frames_dict['Software'] = []
    input_Software.bind("<FocusOut>", lambda e: actualizar_campos_autores(input_Software, entry_frames_dict['Software'], frame, 69, 3, "Software"))

    return entry_frames_dict

def calcular_puntos_productividad(entry_frames_dict):
    """Calcula los puntos de productividad basados en las entradas y la cantidad de autores"""
    puntos_totales = 0
    
    # Definir los puntos base para cada tipo de publicación
    puntos_base = {
        'A1': 15,
        'A2': 12,
        'B': 8,
        'C': 5,
        'A1C': 8,
        'A2C': 6,
        'BC': 4,
        'CC': 3,
        'A1E': 8,
        'A2E': 6,
        'BE': 4,
        'CE': 3,
        'TI': 12,
        'TN': 8,
        'TID': 12,
        'TND': 8,
        'LaborInv': 20,
        'LibrosT': 15,
        'LEnsayos': 15,
        'Premios': 15,
        'Patentes': 25,
        'Traduccion': 12,
        'ObrasI': 20,
        'ObrasN': 14,
        'ObrasAI': 12,
        'ObrasAN': 8,
        'ObrasIA': 14,
        'ObrasIAN': 8,
        'Innovacion': 15,
        'Adaptacion': 8,
        'Software': 15
    }
    
    # Calcular puntos para cada tipo de entrada
    for tipo, frames in entry_frames_dict.items():
        if tipo in puntos_base and frames:
            num_autores = len(frames)
            if num_autores > 0:
                puntos_por_autor = calcular_puntos_por_autores(puntos_base[tipo], num_autores)
                puntos_totales += puntos_por_autor * num_autores
    
    return puntos_totales

# Configurar las entradas dinámicas
entry_frames_dict = setup_dynamic_entries(frame)

# Botón para calcular
boton_enviar = tk.Button(frame, text="Calcular", command=Calcular, font=("Comic Sans MS", 16, "bold"), bd=5, relief="ridge", highlightthickness=2, highlightbackground="black")
boton_enviar.grid(row=70, column=0, columnspan=2, pady=10)

# Iniciar el bucle principal de la ventana
ventana.mainloop()