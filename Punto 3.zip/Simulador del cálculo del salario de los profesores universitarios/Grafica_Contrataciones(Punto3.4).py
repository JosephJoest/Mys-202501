import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Parámetros iniciales
categoria_inicial = 58
puntos_doctorado = 40
experiencia_anios = 10
puntos_experiencia_anual = 4
puntos_productividad_anual = 5
valor_punto = 47450
anios_simulacion = 10
num_profesores = 100  # Número de profesores en la institución

# Diferentes tipos de contratación
# 1. Profesor de planta (como antes)
puntos_totales_planta = categoria_inicial + puntos_doctorado + (experiencia_anios * puntos_experiencia_anual) + (np.arange(0, anios_simulacion + 1) * puntos_productividad_anual)
salarios_planta = puntos_totales_planta * valor_punto

# 2. Profesor ocasional (sin crecimiento por productividad, solo experiencia)
puntos_totales_ocacional = categoria_inicial + puntos_doctorado + (experiencia_anios * puntos_experiencia_anual) + (np.arange(0, anios_simulacion + 1) * 2)
salarios_ocacional = puntos_totales_ocacional * valor_punto

# 3. Profesor catedrático (pago por horas, sin puntos)
salarios_catedratico = np.full(len(salarios_planta), 3000000)  # Sueldo fijo de 3M COP/mes

# Crear tabla de resultados
datos = {
    'Año': np.arange(0, anios_simulacion + 1),
    'Salario Planta (COP)': salarios_planta,
    'Salario Ocasional (COP)': salarios_ocacional,
    'Salario Catedrático (COP)': salarios_catedratico
}
df = pd.DataFrame(datos)
print(df)

# Graficar la evolución del salario para los distintos tipos de contratación
plt.figure(figsize=(10, 5))
plt.plot(np.arange(0, anios_simulacion + 1), salarios_planta, marker='o', linestyle='-', color='b', label='Planta')
plt.plot(np.arange(0, anios_simulacion + 1), salarios_ocacional, marker='s', linestyle='--', color='g', label='Ocasional')
plt.plot(np.arange(0, anios_simulacion + 1), salarios_catedratico, marker='d', linestyle=':', color='r', label='Catedrático')
plt.xlabel('Años de Evolución')
plt.ylabel('Salario (COP)')
plt.title('Comparación de Salarios por Tipo de Contratación')
plt.legend()
plt.grid()
plt.show()
