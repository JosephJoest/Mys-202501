import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Parámetros iniciales
categoria_inicial = 58
puntos_doctorado = 40
experiencia_anios = 10
puntos_experiencia_anual = 4
puntos_productividad_anual = 5
valor_punto = 47450
anios_simulacion = 10
num_profesores = 20  # Número de profesores en la institución

# Cálculo de la evolución del salario
anios = np.arange(0, anios_simulacion + 1)
puntos_totales = categoria_inicial + puntos_doctorado + (experiencia_anios * puntos_experiencia_anual) + (anios * puntos_productividad_anual)
salarios = puntos_totales * valor_punto
nomina_total = salarios * num_profesores

# Crear tabla de resultados
datos = {'Año': anios, 'Puntos Totales': puntos_totales, 'Salario (COP)': salarios, 'Nómina Total (COP)': nomina_total}
df = pd.DataFrame(datos)
print(df)

# Graficar la evolución del salario
plt.figure(figsize=(10, 5))
plt.plot(anios, salarios, marker='o', linestyle='-', color='b', label='Salario Anual')
plt.xlabel('Años de Evolución')
plt.ylabel('Salario (COP)')
plt.title('Evolución del Salario de un Profesor Universitario')
plt.legend()
plt.grid()
plt.show()

# Graficar el impacto en la nómina institucional
plt.figure(figsize=(10, 5))
plt.plot(anios, nomina_total, marker='s', linestyle='-', color='r', label='Nómina Total')
plt.xlabel('Años de Evolución')
plt.ylabel('Nómina Total (COP)')
plt.title('Impacto en la Nómina Institucional')
plt.legend()
plt.grid()
plt.show()
